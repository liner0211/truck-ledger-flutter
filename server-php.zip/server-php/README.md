# 卡车记账 PHP 后端（宝塔部署）

纯 PHP 实现，**无需 Python、无需 Composer**，与 Flutter App API 完全兼容。

> **当前生产域名**：`https://truck.liner0211.online`（PHP 8.0）  
> 逐步部署说明：见 [DEPLOY_truck.liner0211.online.md](./DEPLOY_truck.liner0211.online.md)

## 目录结构

```
server-php/
├── public/          ← 宝塔网站「运行目录」指向这里
│   ├── index.php
│   └── .htaccess
├── lib/             ← 业务逻辑
├── templates/       ← 管理后台页面
├── config.php       ← 从 config.example.php 复制并修改
└── data/            ← 运行时自动创建（SQLite + 附件）
```

## 宝塔部署步骤（5 分钟）

### 1. 上传文件

将整个 `server-php/` 上传到服务器，例如：

```
/www/wwwroot/truck-ledger-api/
```

目录应包含 `public/`、`lib/`、`templates/` 等。

### 2. 创建配置文件

```bash
cd /www/wwwroot/truck-ledger-api
cp config.example.php config.php
```

编辑 `config.php`，**务必修改**：

```php
'jwt_secret' => '至少32位随机字符串',
'admin_password' => '你的管理后台密码',
```

### 3. 添加网站

宝塔 → **网站** → **添加站点**

| 项 | 值 |
|----|-----|
| 域名 | `api.你的域名.com` 或服务器 IP |
| 根目录 | `/www/wwwroot/truck-ledger-api/public` |
| PHP 版本 | **7.4 或 8.x**（推荐 8.0+） |

> 关键：**运行目录必须选 `public`**，不要指到上一级。

### 4. 设置目录权限

宝塔 → 网站 → 设置 → **权限**：

- `data/` 目录（若不存在，先访问一次网站会自动创建）需 **可写**
- 或 SSH 执行：

```bash
mkdir -p /www/wwwroot/truck-ledger-api/data/attachments
chown -R www:www /www/wwwroot/truck-ledger-api/data
chmod -R 755 /www/wwwroot/truck-ledger-api/data
```

### 5. Nginx 配置（重要）

站点 → **设置** → **配置文件**，在 `server { ... }` 内确认/添加：

```nginx
client_max_body_size 25m;

location / {
    try_files $uri $uri/ /index.php?$query_string;
}

# App 使用 Authorization: Bearer，需传给 PHP
location ~ \.php$ {
    include enable-php-80.conf;   # 按你的 PHP 版本，可能是 enable-php-74.conf
    fastcgi_param HTTP_AUTHORIZATION $http_authorization;
}
```

保存后重载 Nginx。

### 6. SSL（推荐）

站点 → **SSL** → Let's Encrypt → 开启 **强制 HTTPS**。

### 7. 验证

浏览器访问：

- `https://api.你的域名.com/api/health` → `{"status":"ok"}`
- `https://api.你的域名.com/admin` → 管理后台登录

### 8. App 配置

手机登录页服务器地址：

```
https://api.你的域名.com
```

不要带末尾 `/`，不要带端口号（走 443）。

---

## API 接口（与 App 一致）

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `/api/health` | 健康检查 |
| POST | `/api/auth/register` | 注册 |
| POST | `/api/auth/login` | 登录 |
| GET | `/api/ledger` | 拉取账本（Bearer Token） |
| PUT | `/api/ledger` | 上传账本 |
| GET | `/api/attachments` | 附件列表 |
| POST | `/api/attachments/{name}` | 上传附件 |
| GET | `/api/attachments/{name}` | 下载附件 |

---

## 数据备份

定期备份：

```
/www/wwwroot/truck-ledger-api/data/
├── truck_ledger.db
└── attachments/
```

宝塔 → **计划任务** → 压缩备份 `data/` 目录。

---

## 常见问题

### 502 / 空白页

- PHP 版本是否 7.4+
- 运行目录是否 `public/`
- 查看网站 **日志**

### App 登录 401 / 无法同步

- Nginx 是否加了 `fastcgi_param HTTP_AUTHORIZATION $http_authorization;`
- `config.php` 中 `jwt_secret` 是否已设置

### 上传附件失败

- `client_max_body_size 25m;`
- `data/attachments/` 是否可写

### 与 Python 版区别

- 无 `/docs` Swagger 页面（PHP 版未实现）
- 数据库格式相同，可迁移 `data/truck_ledger.db` 和 `attachments/`

---

## 从 Python 版迁移

若之前在 `server/data/` 有数据，复制到 PHP 目录：

```bash
cp -r /path/to/server/data/* /www/wwwroot/truck-ledger-api/data/
chown -R www:www /www/wwwroot/truck-ledger-api/data
```

SQLite 表结构一致，可直接使用。
